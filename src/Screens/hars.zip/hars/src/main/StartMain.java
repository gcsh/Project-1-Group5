package main;


public class StartMain {
	public static void main(String[] args){
		GUIFrames.run();
	}
}
